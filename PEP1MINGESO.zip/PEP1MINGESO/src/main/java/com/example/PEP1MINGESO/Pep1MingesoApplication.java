package com.example.PEP1MINGESO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pep1MingesoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pep1MingesoApplication.class, args);
	}

}
